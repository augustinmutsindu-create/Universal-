package com.example.universallauncher

import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.GridView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var gridView: GridView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(0, 48, 0, 24)
        }

        gridView = GridView(this).apply {
            numColumns = 4
            horizontalSpacing = 16
            verticalSpacing = 24
            setPadding(24, 0, 24, 48)
        }

        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(title)
            addView(gridView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        setContentView(root)

        loadApps()
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val apps: List<ResolveInfo> = packageManager.queryIntentActivities(intent, 0)

        gridView.adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(position: Int) = apps[position]
            override fun getItemId(position: Int) = position.toLong()

            override fun getView(position: Int, convertView: android.view.View?, parent: ViewGroup): android.view.View {
                val app = apps[position]
                val view = convertView ?: layoutInflater.inflate(R.layout.app_item, parent, false)

                val icon = view.findViewById<android.widget.ImageView>(R.id.appIcon)
                val label = view.findViewById<TextView>(R.id.appLabel)

                icon.setImageDrawable(app.loadIcon(packageManager))
                label.text = app.loadLabel(packageManager)

                view.setOnClickListener {
                    val launchIntent = packageManager.getLaunchIntentForPackage(
                        app.activityInfo.packageName
                    )
                    launchIntent?.let { startActivity(it) }
                }
                return view
            }
        }
    }
}
