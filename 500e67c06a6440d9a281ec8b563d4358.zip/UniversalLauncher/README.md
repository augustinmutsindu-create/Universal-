# Universal Launcher

Lanceur Android minimal qui affiche toutes les applications installées dans une grille et permet de les ouvrir.

## Installation

1. Ouvrez le dossier `UniversalLauncher` dans Android Studio.
2. Attendez la synchronisation Gradle.
3. Cliquez sur **Run** pour installer l’application sur un téléphone ou émulateur.
4. Dans les réglages Android, choisissez **Applications par défaut > Application d’accueil** puis sélectionnez **Universal Launcher**.

## Prochaines évolutions possibles

- Thèmes inspirés de One UI, HyperOS/MIUI, Pixel Launcher et Huawei.
- Widget d’horloge et météo.
- Recherche universelle d’applications, contacts et fichiers.
- Gestes, dossier, dock et personnalisation des icônes.
